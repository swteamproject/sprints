package com.SWESection.Repositories;

import org.springframework.data.repository.CrudRepository;

import com.SWESection.Entities.User;

public interface UserRepository 
extends CrudRepository<User, Integer> {

	User findByEmailAndPassword(String email, int password);
 

}
