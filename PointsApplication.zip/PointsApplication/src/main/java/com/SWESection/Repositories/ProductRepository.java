package com.SWESection.Repositories;

import org.springframework.data.repository.CrudRepository;

import com.SWESection.Entities.Product;

public interface ProductRepository 
extends CrudRepository<Product, Integer> {

	//
	//User findByEmailAndPassword(String email, int password);
 

}
