package com.SWESection.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.SWESection.Entities.User;
import com.SWESection.Repositories.UserRepository;

@Controller
public class UserController {
	
	@Autowired
	private UserRepository repo;

	@GetMapping("/addUser")
	public String showAddStudentForm(Model model){
		model.addAttribute("student", new User());
		return "register";
	}
	
	@PostMapping("/addUser")
	public String addStudent(Model model, @ModelAttribute User student){
		System.out.println(student.getName());
		System.out.println(student.getEmail());
		System.out.println(student.getPassword());
		repo.save(student);
		model.addAttribute("student", new User());
		return "register";	
	}
//	@GetMapping("/login")
//	public String showAdduserForm(Model model){
//		model.addAttribute("u", new User());
//		return "login";
//	}
//	@PostMapping("/login")
//	public String login(Model model, @ModelAttribute User user) {
//		model.addAttribute("user", new User());
//		for (User demo : repo.findAll()) {
//			if(demo.getEmail().equals(user.getEmail())&&demo.getPassword()==user.getPassword())
//			{System.out.println("login pass");
//			System.out.println("---------"+demo.getEmail());
//			System.out.println("****"+demo.getPassword());
//			model.addAttribute("u", new User());
//			//return "login";	
//			}
//			else {
//				System.out.println("login Faild");
//		}
//		}
//		return "login";
//	}
//	
	@GetMapping("/showAllUser")
	public String showAllStudents(Model model){
		Iterable<User> studentsIterable = repo.findAll();
		List<User> studentsList = new ArrayList<User>();
		for(User student : studentsIterable){
			studentsList.add(student);
		}
		model.addAttribute("students", studentsList);
		return "show-all-User";
	}
}
