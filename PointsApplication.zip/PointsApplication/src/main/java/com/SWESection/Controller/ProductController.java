package com.SWESection.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.SWESection.Entities.Product;
import com.SWESection.Entities.User;
import com.SWESection.Repositories.ProductRepository;

@Controller
public class ProductController {

	@Autowired
	private ProductRepository repo;

	@GetMapping("/addproduct")
	public String showAddStudentForm(Model model) {
		model.addAttribute("product", new Product());
		return "addproduct";
	}
	
	@PostMapping("/addproduct")
	public String addProduct(Model model, @ModelAttribute Product product) {
		model.addAttribute("product", new Product());
//		for (Product pro : repo.findAll()) {
//			if (pro.getName().equals(product.getName()) && pro.getCategory().equals(product.getCategory())) {
				System.out.println(product.getName());
				System.out.println(product.getCategory());
				//pro.setQuentity(product.getQuentity() + product.getQuentity());
				System.out.println(product.getQuentity());
				repo.save(product);
			//} 
				//else {
//				System.out.println(pro.getName());
//				System.out.println(pro.getCategory());
//				pro.setQuentity(pro.getQuentity());
//				System.out.println(pro.getQuentity());
//				repo.save(pro);
//				model.addAttribute("product", new Product());
//				
//			}
		//}
		return "addproduct";
	}	
	
	@GetMapping("/showAllProducts")
	public String showAllProducts(Model model) {
		Iterable<Product> studentsIterable = repo.findAll();
		List<Product> productList = new ArrayList<Product>();
		for (Product student : studentsIterable) {
			productList.add(student);
		}
		model.addAttribute("products", productList);
		return "show-all-product";
	}
}
